#!/bin/bash
gradle clean check